#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

// Структура узла 
struct Node {
    char data;
    Node* next;
    Node* prev;
};



// Генерация случайного символа
char getRandomChar() {
    int r = rand() % 53; // 26 строчных + 26 заглавных + 1 пробел
    if (r < 26) return 'a' + r;
    if (r < 52) return 'A' + (r - 26);
    return ' ';
}

// Определение длины списка
int getLength(Node* head) {
    int count = 0;
    while (head != nullptr) {
        count++;
        head = head->next;
    }
    return count;
}



// 3. очистка памяти
void deleteList(Node*& head, Node*& tail) {
    Node* current = head;
    while (current != nullptr) {
        Node* nextNode = current->next;
        delete current;
        current = nextNode;
    }
    head = nullptr;
    tail = nullptr;
}

// 1. Создание списка
void createList(Node*& head, Node*& tail) {
    deleteList(head, tail); // Очищаем, если список уже существовал

    int n;
    cout << "Vvedite kolichestvo elementov spiska (n >= 2): ";
    cin >> n;

    if (n < 2) {
        cout << "Oshibka: n dolzhno byt' >= 2.\n";
        return;
    }

    for (int i = 0; i < n; ++i) {
        Node* newNode = new Node;
        newNode->data = getRandomChar();
        newNode->next = nullptr;
        newNode->prev = tail;

        if (head == nullptr) {
            head = newNode;
        } else {
            tail->next = newNode;
        }
        tail = newNode;
    }
    cout << "Spisok iz " << n << " elementov uspeshno sozdan.\n";
}

// 2. Вывод списка на экран 
void printList(Node* head, Node* tail) {
    if (head == nullptr) {
        cout << "List is empty\n";
        return;
    }

    
    cout << "Ot golovy k hvostu: ";
    Node* current = head;
    while (current != nullptr) {
        if (current->data == ' ') cout << "' '"; // Для наглядности пробелов
        else cout << current->data;
        
        if (current->next != nullptr) cout << " => ";
        current = current->next;
    }
    cout << "\n";

    
    cout << "Ot hvosta k golove: ";
    current = tail;
    while (current != nullptr) {
        if (current->data == ' ') cout << "' '";
        else cout << current->data;
        
        if (current->prev != nullptr) cout << " => ";
        current = current->prev;
    }
    cout << "\n";
}

// 4. Вставка одного элемента
void insertElement(Node*& head, Node*& tail) {
    int pos, len = getLength(head);
    cout << "Vvedite pozitsiyu dlya vstavki (1 - " << len + 1 << "): ";
    cin >> pos;

    if (pos < 1 || pos > len + 1) {
        cout << "Nekorrektnaya pozitsiya!\n";
        return;
    }

    char val;
    cout << "Vvedite simvol dlya vstavki: ";
    cin >> val;

    Node* newNode = new Node;
    newNode->data = val;

    
    if (head == nullptr) {
        newNode->next = nullptr;
        newNode->prev = nullptr;
        head = tail = newNode;
    } 
    
    else if (pos == 1) {
        newNode->next = head;
        newNode->prev = nullptr;
        head->prev = newNode;
        head = newNode;
    } 
    
    else if (pos == len + 1) {
        newNode->next = nullptr;
        newNode->prev = tail;
        tail->next = newNode;
        tail = newNode;
    } 
    
    else {
        Node* current = head;
        for (int i = 1; i < pos - 1; ++i) {
            current = current->next;
        }
        newNode->next = current->next;
        newNode->prev = current;
        current->next->prev = newNode;
        current->next = newNode;
    }
    cout << "Element vstavlen.\n";
}

// 5. Удаление одного элемента
void deleteElement(Node*& head, Node*& tail) {
    if (head == nullptr) {
        cout << "Spisok pust, udalyat' nechego.\n";
        return;
    }

    int pos, len = getLength(head);
    cout << "Vvedite pozitsiyu dlya udaleniya (1 - " << len << "): ";
    cin >> pos;

    if (pos < 1 || pos > len) {
        cout << "Nekorrektnaya pozitsiya!\n";
        return;
    }

    Node* toDelete = head;

   
    for (int i = 1; i < pos; ++i) {
        toDelete = toDelete->next;
    }

    
    if (head == tail) {
        head = tail = nullptr;
    } 
    
    else if (toDelete == head) {
        head = head->next;
        head->prev = nullptr;
    } 
   
    else if (toDelete == tail) {
        tail = tail->prev;
        tail->next = nullptr;
    } 
   
    else {
        toDelete->prev->next = toDelete->next;
        toDelete->next->prev = toDelete->prev;
    }

    delete toDelete;
    cout << "Element udalen.\n";
}

// 6. Удаление пробелов
void removeSpaces(Node*& head, Node*& tail) {
    if (head == nullptr) {
        cout << "Spisok pust.\n";
        return;
    }

    cout << "--- Ishodnaya posledovatel'nost' ---\n";
    printList(head, tail);

    Node* current = head;
    while (current != nullptr) {
        if (current->data == ' ') {
            Node* toDelete = current;
            current = current->next; 

            
            if (toDelete == head && toDelete == tail) {
                head = nullptr;
                tail = nullptr;
            }
            // 
            else if (toDelete == head) {
                head = toDelete->next;
                if (head != nullptr) {
                    head->prev = nullptr; 
                }
            }
            
            else if (toDelete == tail) {
                tail = toDelete->prev;
                if (tail != nullptr) {
                    tail->next = nullptr; 
                }
            }
            
            else {
                toDelete->prev->next = toDelete->next;
                toDelete->next->prev = toDelete->prev;
            }

            delete toDelete; 
        } else {
            current = current->next; 
        }
    }

    cout << "\n--- Posledovatel'nost' posle udaleniya probelov ---\n";
    printList(head, tail); 
}



int main() {
    srand(static_cast<unsigned>(time(0)));

    Node* head = nullptr;
    Node* tail = nullptr;
    int choice;

    do {
        cout << 
              "(1) Sozdanie spiska\n"
             << "(2) Vyvod spiska na ekran\n"
             << "(3) Udalenie vsego spiska\n"
             << "(4) Vstavka odnogo elementa\n"
             << "(5) Udalenie odnogo elementa\n"
             << "(6) Zadanie punkta 2 (Udalit' probely)\n"
             << "(7) Stop\n"
              
             << "Vash vybor: ";
        
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(10000, '\n');
            cout << "Pozhaluysta, vvedite chislo.\n";
            continue;
        }

        switch (choice) {
            case 1: createList(head, tail); break;
            case 2: printList(head, tail); break;
            case 3: 
                deleteList(head, tail); 
                cout << "Spisok udalen.\n";
                break;
            case 4: insertElement(head, tail); break;
            case 5: deleteElement(head, tail); break;
            case 6: removeSpaces(head, tail); break;
            case 7: 
                deleteList(head, tail); 
                cout << "Zavershenie programmy.\n"; 
                break;
            default: cout << "Nevernyy punkt menyu. Povtorite.\n";
        }
    } while (choice != 7);

    return 0;
}