#include <iostream>

using namespace std;

int main() {
    
    unsigned int F;
    
    cout << "Введите число F (в десятичной форме): ";
    if (!(cin >> F)) {
        cout << "Ошибка ввода." << endl;
        return 1;
    }

    
    // Сдвигаем число вправо на 8 позиций и «отрезаем» лишнее с помощью маски 0xFF (8 единиц)
    unsigned int manufacturer_code = (F >> 8) & 0xFF;
    
    cout << "Код производителя и модели: " << manufacturer_code << endl;

    //  Извлекаем нужные биты-атрибуты через наложение масок.
   
    
    // Руль (бит 0): 1 - правый, 0 - левый
    bool is_right_hand = (F & (1 << 0)) != 0;
    bool is_left_hand  = (F & (1 << 0)) == 0;

    // Страна (бит 1): 1 - Япония
    bool is_japanese = (F & (1 << 1)) != 0;

    // Тип кузова (бит 2): 1 - джип
    bool is_jeep = (F & (1 << 2)) != 0;

    // Трансмиссия (бит 5): 0 - механика ("на коробке")
    bool is_manual = (F & (1 << 5)) == 0;

    // Электродвигатель (бит 6): 1 - есть (означает, что это гибрид)
    bool is_hybrid = (F & (1 << 6)) != 0;

    // Тип двигателя (бит 7): 0 - дизельный
    bool is_diesel = (F & (1 << 7)) == 0;

    
    
    // "праворульный японский гибрид"
    bool condition_A = is_right_hand && is_japanese && is_hybrid;
    
    // "леворульный дизельный джип на коробке"
    bool condition_B = is_left_hand && is_diesel && is_jeep && is_manual;

    
    if (condition_A || condition_B) {
        cout << "Результат: Автомобиль ПОДХОДИТ под заданные критерии." << endl;
        if (condition_A) {
            cout << "-> Это праворульный японский гибрид." << endl;
        } else {
            cout << "-> Это леворульный дизельный джип на механике." << endl;
        }
    } else {
        cout << "Результат: Автомобиль НЕ ПОДХОДИТ под критерии." << endl;
    }

    return 0;
}